y = int
y == 1
count = int
masinput = str
while y == 1:
	masinput = str(input("FC:\\"))
# 8 bit integer counting command script (1 by one)
if input == ("FC:\\8BITTEST1X"):
	count = 0
	count = int
	count =+ 1
	print (count)
while not (count > 256):
    count += 1
    print (count)
else:
        print ("You have successfully counted to a 8 bit integer")