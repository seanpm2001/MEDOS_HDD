testconfirm = int(input("Did the command look right? type 1 to confirm, type anything else and/or press enter to quit "))
if testconfirm == 1:
    print ("Command test successful!")
    print ("Shutting down, please wait")
else:
    print ("Shutting down")