# I have attempted this all-in-one system program file a few times, but I haven't been successful
# This is another attempt, but I have it more together now
# Original broken script:
'''
print ("MEDOS Beta build 2")
print ("Developer debug build")
print ("Checking Memory")
print ("Total disk space: 16 TB")
print ("Speed: 6 MB/S")
print ("32 bit processor")
print ("Current directory is FC:/")
print ("File count: 5")
print ("Memory used: 20000 bytes")
print ("Run a command to begin, type help for help")
in1 = input("FC:/")
if (in1 = ("dir")): 
	print ("Directory of FC1")
	print ("Test.txt")
	print ("Test.bmp")
	print ("Test.wav")
	print ("Test.py")
	print ("Test.rtf")
if (in1 = ("help")):
	print ("Help list")
	print ("DIR = Directory")
	print ("CLS = Clear screen")
	print ("HELP = Help guide")
	print ("RUN = Run a program/file")
	print ("DEL = Delete the selected file")
	print ("COLOR = Change the text color of the terminal")
	print ("EXIT = Shut down the system")
	print ("CD = Choose a directory, type .. or the directory name afterwards, and you will go to the next directory")
	print ("PLAY = Play the currently selected audio or video")
	print ("EJECT = Eject the system, make it ready for ejecting the drive")
	print ("NETW = Change the current network")
	print ("DISCON = Disconnect from the internet, go offline")
if (in1 = ("cls")):
	print ("This command is unavailable")
if (in1 = ("run")):
	print ("The syntax of the command is incorrect")
if (in1 = ("del")):
	print ("The syntax of the command is incorrect")
if (in1 = ("color")):
	print ("This command is unavailable")
if (in1 = ("exit")):
	print ("This command is unavailable")
if (in1 = ("CD")):
	print ("This command is unavailable")
if (in1 = ("play")):
	print ("This command is unavailable")
if (in1 = ("eject")):
	print ("The syntax of the command is incorrect")
if (in1 = ("netw")):
	print ("This command is unavailable")
if (in1 = ("discon")):
	print ("This command is unavailable")
else:
	print (in1)
'''
'''
print ("MEDOS Beta build 1")
print ("Developer debug build")
print ("Checking Memory")
print ("Total disk space: 16 TB")
print ("Speed: 6 MB/S")
print ("32 bit processor")
print ("Current directory is FC:/")
print ("File count: 5")
print ("Memory used: 20000 bytes")
print ("Run a command to begin, type help for help")
in1 = input("FC:/")
if (in1 == ("dir")): 
    print ("Directory of FC1")
    print ("Test.txt")
    print ("Test.bmp")
    print ("Test.wav")
    print ("Test.py")
    print ("Test.rtf")
	else:
		if (in1 == ("help")):
			print ("Help list")
			print ("DIR = Directory")
			print ("CLS = Clear screen")
			print ("HELP = Help guide")
			print ("RUN = Run a program/file")
			print ("DEL = Delete the selected file")
			print ("COLOR = Change the text color of the terminal")
			print ("EXIT = Shut down the system")
			print ("CD = Choose a directory, type .. or the directory name afterwards, and you will go to the next directory")
			print ("PLAY = Play the currently selected audio or video")
			print ("EJECT = Eject the system, make it ready for ejecting the drive")
			print ("NETW = Change the current network")
			print ("DISCON = Disconnect from the Internet, go offline")
			print ("DRCHECK = Test your drives memory")
			print ("SPCHK = Calculate the amount of space being used")
			print ("VMOUTRUN = Use this command to launch programs OUTSIDE of the hard drive operating system, and onto the targeted receiver device")
			print ("VMORUTOG = Toggle launching programs outside of the hard drive operating systems to the other device on and off")
			print ("COMPBLOG = View the file compatibility of the system")
			print ("PREVTOG = Toggle file previews")
			print ("UPDUSR2 = Check for updates for the network receiver device")
			print ("RENAME = Rename the selected file/directory")
			print ("URENAME = Undo the recent renaming action")
			print ("CALC = Run a calculator")
			print ("USR2 = change the settings for the receiver device")
			else:
				if (in1 == ("cls")):
					print ("This command is unavailable")
					else:
						if (in1 == ("run")):
							print ("The syntax of the command is incorrect")
							else:
								if (in1 == ("del")):
									print ("The syntax of the command is incorrect")
									else:
										if (in1 == ("color")):
											print ("This command is unavailable")
											else:
												if (in1 == ("exit")):
													print ("This command is unavailable")
													else:
														if (in1 == ("CD")):
															print ("This command is unavailable")
															else:
																if (in1 == ("play")):
																	print ("This command is unavailable")
																	else:
																		if (in1 == ("eject")):
																			print ("The syntax of the command is incorrect")
																			else:	
																				if (in1 == ("netw")):
																					print ("This command is unavailable")
																					else:
																						if (in1 == ("discon")):
																							print ("This command is unavailable"
																							else:
																								print (in1)
																								if (in1 == ("drcheck")
																									print ("Testing memory, please wait..."_
																									else:
																										if (in1 == SPCHK")
																											print ("Calculating all files on your drive please wait...")
																											print ("This will take a few moments")
																											else: 
																												if (in1 == VMOUTRUN")
																													print ("Select a program to run on |USER2|")
																													else:
																														if (in1 == "VMRUTOG")
																															if (ftoguser = 1):
																																print ("Turning off outtoggle for |USER2|")
																																ftoguser = 0
																																else:
																																	if (ftoguser = 0):
																																		print ("Turning on outtoggle for |USER2|")
																																		ftoguser = 1
																																		else:
																																			if (in1 == "COMPBLOG")
																																				print ("File compatibility for MEDOS HDD")
																																				print ("Documents")
																																				print ("RTF")
																																				print ("TXT")
																																				print ("XPS")
																																				print ("ODS")
																																				print ("ODT")
																																				print ("ODX")
																																				print ("PDF")
																																				print ("Images")
																																				print ("BMP")
																																				print ("DMP")
																																				print ("PNG")
																																				print ("JPEG")
																																				print ("JPE")
																																				print ("JFIF")
																																				print ("GIF")
																																				print ("TIF")
																																				print ("TIFF")
																																				print ("SVG")
																																				print ("PSD")
																																				print ("ICO")
																																				print ("ICN")
																																				print ("PNS")
																																				print ("Videos")
																																				print ("MP4")
																																				print ("MP2")
																																				print ("AVI")
																																				print ("WMV")
																																				print ("3GP")
																																				print ("WEBM")
																																				print ("WLMP")
																																				print ("WMMP")
																																				print ("MOV")
																																				print ("M4V")
																																				print ("MKV")
																																				print ("Music")
																																				print ("OGG")
																																				print ("MP3")
																																				print ("MID")
																																				print ("MIDI")
																																				print ("FLAC")
																																				print ("WAV")
																																				print ("System")
																																				print ("SYS")
																																				print ("PY")
																																				print ("BAT")
																																				print ("DAT")
																																				print ("INI")
																																				print ("SLN")
																																				print ("EXE")
																																				print ("0")
																																				print ("Media")
																																				print ("IMG")
																																				print ("IMAGE")
																																				print ("ISO")
																																				print ("ZIP")
																																				print ("7Z")
																																				print ("TAR")
																																				print ("RAR")
																																				print ("ISO")
																																				print ("DMG")
																																				print ("Other")
																																				print ("URL")
																																				print ("INK")
																																				print ("TORRENT")
																																				else:
																																					if (in1 == "PREVTOG")
																																						if (PRTOG == 1):
																																							print ("Turning off file previews")
																																							PRTOG == 0
																																							else:
																																								if (PRTOG == 0):
																																									print ("Turning on file preview")
																																									else:
																																										if (in1 == "UPDUSR2")
																																											print ("Checking for updates for |USER2|")
																																											else:
																																												if (in1 == "RENAME")
																																													print ("Rename a file")
																																													else:
																																														if (in1 == "URENAME")
																																															print ("Do you want to revert the last rename? Y/N")
																																															else:
																																																if (in1 == CALC")
																																																	print ("Starting calculator")
																																																	else:
																																																		if (in1 == "USR2")
																																																			print ("Change settings for the receiver device, press ESC to cancel, TAB to quit")
																																																			print ("Device location {}")
																																																			print ("Device size {}")
																				
																																																
																																							
																																																																																																																						
'''
# Somewhat working incomplete driver listing script for setup: 
'''
print ("Welcome to the MEDOS setup utility!")
print ("You are in: Disk 0")
print ("Please insert disk 1, when you are ready, type SET")

# Floppy Disk Legacy 1 (360k)
# Optimized for the following operating systems:
# Windows 1x
# Windows 2x
# Windows 2.1x
# Windows 3x
# Windows 3.1x
# Mac System 1
# Mac System 2
# Mac System 3
# Mac System 4
# Mac System 5
# Mac System 6
print ("Please insert disk 1 labeled: SysCore1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 360K loaded
print ("Please insert disk 2 labeled: SysCore2")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 720K loaded
print ("Please insert disk 3 labeled: SysCore3")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 1080K loaded
print ("Please insert disk 4 labeled: SysCore4")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 1440K loaded
print ("Please insert disk 5 labeled: SysCore5")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 1800K loaded
print ("Please insert disk 6 labeled: Storsys1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2160K loaded
print ("Please insert disk 7 labeled: Storsys2")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2520K loaded
print ("Please insert disk 8 labeled: Storsys3")
print ("If you think you have enough memory: 360K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2880K loaded
print ("Please insert disk 9 labeled: Storsys4")
print ("If you think you have enough memory: 720K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 3240K loaded 
print ("Please insert disk 10 labeled: Storsys5")
print ("If you think you have enough memory: 1080K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 3600K loaded
print ("Please insert disk 11 labeled: Storsys6")
print ("If you think you have enough memory: 1440K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 3960K loaded
print ("Please insert disk 12 labeled: Storsys7")
print ("If you think you have enough memory: 1800K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 4320K loaded
print ("Please insert disk 13 labeled: Storsys8")
print ("If you think you have enough memory: 2160K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 4680K loaded
print ("Please insert disk 14 labeled: Storsys9")
print ("If you think you have enough memory: 2520K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5040K loaded
print ("Please insert disk 15 labeled: Strsys10")
print ("If you think you have enough memory: 2880K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5400 K loaded
print ("Please insert disk 16 labeled: Strsys11")
print ("If you think you have enough memory: 3240K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5760K loaded
print ("Please insert disk 17 labeled: Strsys12")
print ("If you think you have enough memory: 3600K (3.6 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 6120K loaded
print ("Please insert disk 18 labeled: Strsys13")
print ("If you think you have enough memory: 3960K (3.9 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 6480K loaded
print ("Please insert disk 19 labeled: Strsys14")
print ("If you think you have enough memory: 4320K (4.3 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 6840K loaded
print ("Please insert disk 20 labeled: Strsys15")
print ("If you think you have enough memory: 4680K (4.6 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")

# Floppy Disk Legacy 2 (720k)
# Optimized for the following operating systems:
# Windows 3.1x
# Windows 95
# Windows NT 4
# Windows 3.5x
# Mac System 6
# Mac System 7
# Mac System 8
print ("Please insert disk 1 labeled: SysCore1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 720K loaded 
print ("Please insert disk 2 labeled: SysCore2")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 1440K loaded
print ("Please insert disk 3 labeled: SysCore3")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2160K loaded 
print ("Please insert disk 4 labeled: SysCore4")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2880K loaded 
print ("Please insert disk 5 labeled: Storsys1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 3600K loaded 
print ("Please insert disk 6 labeled: Storsys2")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 4320K loaded 
print ("Please insert disk 7 labeled: Storsys3")
print ("If you think you have enough memory: 720K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5040K loaded 
print ("Please insert disk 8 labeled: Storsys4")
print ("If you think you have enough memory: 1440K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5760K loaded 
print ("Please insert disk 9 labeled: Storsys5")
print ("If you think you have enough memory: 2160K (2.1 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 6480K loaded 
print ("Please insert disk 10 labeled: Storsys6")
print ("If you think you have enough memory: 2880K (2.8 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 7200K loaded 
print ("Please insert disk 11 labeled: Storsys7")
print ("If you think you have enough memory: 3600K (3.6 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 7920K loaded 
print ("Please insert disk 12 labeled: Storsys8")
print ("If you think you have enough memory: 4320K (4.3 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 8640K loaded 
print ("Please insert disk 13 labeled: Storsys9")
print ("If you think you have enough memory: 5040K (5.0 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 9360K loaded 
print ("Please insert disk 14 labeled: Strsys10")
print ("If you think you have enough memory: 5760K (5.7 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 10080K loaded 
print ("Please insert disk 15 labeled: Strsys11")
print ("If you think you have enough memory: 6480K (6.4 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 10800K loaded 
print ("Please insert disk 16 labeled: Strsys12")
print ("If you think you have enough memory: 7200K (7.2 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 11520K loaded 
print ("Please insert disk 17 labeled: Strsys13")
print ("If you think you have enough memory: 7920K (7.9 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 12240K loaded 
print ("Please insert disk 18 labeled: Strsys14")
print ("If you think you have enough memory: 8640K (8.6 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 12960K loaded 
print ("Please insert disk 19 labeled: Strsys15")
print ("If you think you have enough memory: 9360K (9.3 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 13680K loaded 
print ("Please insert disk 20 labeled: Strsys15")
print ("If you think you have enough memory: 10080K (10.0 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")

# Floppy Disk Legacy 3 (1200k)
# Optimized for the following operating systems:
# Windows 98
# Windows 98 Second Edition
# Windows ME
# Windows 2000
# Mac System 7
# Mac System 8
# Mac System 9
# Mac OS X 10.0
# Mac OS X 10.1
# Mac OS X 10.2

# Floppy Disk Legacy 4 (1440k)
# Optimized for the following operating systems:
# Windows 98
# Windows 98 Second Edition
# Windows ME
# Windows 2000
# Windows XP 
# Mac System 9
# Mac OS X 10.0
# Mac OS X 10.1
# Mac OS X 10.2
# Mac OS X 10.3
# Mac OS X 10.4
# Mac OS X 10.5
# Mac OS X 10.6
# Mac OS X 10.7
# Mac OS X 10.8
# Mac OS X 10.9
# Mac OS X 10.10
print ("Please insert disk 1 labeled: SysCore1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 1440K loaded 
print ("Please insert disk 2 labeled: SysCore2")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 2880K loaded 
print ("Please insert disk 3 labeled: Storsys1")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 4320K loaded 
print ("Please insert disk 4 labeled: Storsys2")
print ("If you think you have enough memory: 1440K you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 5760K loaded 
print ("Please insert disk 5 labeled: Storsys3")
print ("If you think you have enough memory: 2880K (2.8 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 7200K loaded 
print ("Please insert disk 6 labeled: Storsys4")
print ("If you think you have enough memory: 4320K (4.3 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 8640K loaded 
print ("Please insert disk 7 labeled: Storsys5")
print ("If you think you have enough memory: 5760K (5.7 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 10080K loaded 
print ("Please insert disk 8 labeled: Storsys6")
print ("If you think you have enough memory: 7200K (7.2 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 11520K loaded 
print ("Please insert disk 9 labeled: Storsys7")
print ("If you think you have enough memory: 8640K (8.6 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")
# 12960K loaded 
print ("Please insert disk 10 labeled: Storsys7")
print ("If you think you have enough memory: 10080K (10.0 Megabytes) you can continue by pressing X")
print ("Once disk is loaded, setup will automatically continue")
print ("DO NOT UNMOUNT ANY PREVIOUS DISKETTES!")

# System codes

'''
'''

# Floppy Legacy 1

floppy1 = 1008.0
floppy2 = 1008.1
floppy3 = 1008.2
floppy4 = 1008.3
floppy5 = 1008.4
floppy6 = 1008.5
floppy7 = 1008.6
floppy8 = 1008.7
floppy9 = 1008.8
floppy10 = 1008.9
floppy11 = 1008.10
floppy12 = 1008.11
floppy13 = 1008.12
floppy14 = 1008.13
floppy15 = 1008.14
floppy16 = 1008.15
floppy17 = 1008.16
floppy18 = 1008.17
floppy19 = 1008.18
floppy20 = 1008.19

# Floppy Legacy 2

floppy1 = 2008.0
floppy2 = 2008.1
floppy3 = 2008.2
floppy4 = 2008.3
floppy5 = 2008.4
floppy6 = 2008.5
floppy7 = 2008.6
floppy8 = 2008.7
floppy9 = 2008.8
floppy10 = 2008.9
floppy11 = 2008.10
floppy12 = 2008.11
floppy13 = 2008.12
floppy14 = 2008.13
floppy15 = 2008.14
floppy16 = 2008.15
floppy17 = 2008.16
floppy18 = 2008.17
floppy19 = 2008.18
floppy20 = 2008.19

# Floppy Legacy 3

floppy1 = 3008.0
floppy2 = 3008.1
floppy3 = 3008.2
floppy4 = 3008.3
floppy5 = 3008.4
floppy6 = 3008.5
floppy7 = 3008.6
floppy8 = 3008.7
floppy9 = 3008.8
floppy10 = 3008.9
floppy11 = 3008.10
floppy12 = 3008.11
floppy13 = 3008.12
floppy14 = 3008.13
floppy15 = 3008.14
floppy16 = 3008.15
floppy17 = 3008.16
floppy18 = 3008.17
floppy19 = 3008.18
floppy20 = 3008.19

# Floppy Legacy 4

floppy1 = 4008.0
floppy2 = 4008.1
floppy3 = 4008.2
floppy4 = 4008.3
floppy5 = 4008.4
floppy6 = 4008.5
floppy7 = 4008.6
floppy8 = 4008.7
floppy9 = 4008.8
floppy10 = 4008.9
floppy11 = 4008.10
floppy12 = 4008.11
floppy13 = 4008.12
floppy14 = 4008.13
floppy15 = 4008.14
floppy16 = 4008.15
floppy17 = 4008.16
floppy18 = 4008.17
floppy19 = 4008.18
floppy20 = 4008.19

# Cassette Legacy 1

# USB Legacy 1

USBstoragecode1 = 10016.0 
USBspeedcode1 = 10061.0
USBstoragecode2 = 10016.1
USBspeedcode2 = 10061.1
USBstoragecode3 = 10016.2 
USBspeedcode3 = 10061.2
USBstoragecode4 = 10016.3
USBspeedcode4 = 10061.3
USBstoragecode5 = 10016.4 
USBspeedcode5 = 10061.4
USBstoragecode6 = 10016.5
USBspeedcode6 = 10061.5
USBstoragecode7 = 10016.6
USBspeedcode7 = 10061.6
USBstoragecode8 = 10016.7 
USBspeedcode8 = 10061.7
USBstoragecode9 = 10016.8
USBspeedcode9 = 10061.8
USBstoragecode10 = 10016.9
USBspeedcode10 = 10061.9

# USB Legacy 2

USBstoragecode1 = 20016.0 
USBspeedcode1 = 20061.0
USBstoragecode2 = 20016.1
USBspeedcode2 = 20061.1
USBstoragecode3 = 20016.2 
USBspeedcode3 = 20061.2
USBstoragecode4 = 20016.3
USBspeedcode4 = 20061.3
USBstoragecode5 = 20016.4 
USBspeedcode5 = 20061.4
USBstoragecode6 = 20016.5
USBspeedcode6 = 20061.5
USBstoragecode7 = 20016.6
USBspeedcode7 = 20061.6
USBstoragecode8 = 20016.7 
USBspeedcode8 = 20061.7
USBstoragecode9 = 20016.8
USBspeedcode9 = 20061.8
USBstoragecode10 = 20016.9
USBspeedcode10 = 20061.9

# USB Legacy 3

USBstoragecode1 = 30016.0 
USBspeedcode1 = 30061.0
USBstoragecode2 = 30016.1
USBspeedcode2 = 30061.1
USBstoragecode3 = 30016.2 
USBspeedcode3 = 30061.2
USBstoragecode4 = 30016.3
USBspeedcode4 = 30061.3
USBstoragecode5 = 30016.4 
USBspeedcode5 = 30061.4
USBstoragecode6 = 30016.5
USBspeedcode6 = 30061.5
USBstoragecode7 = 30016.6
USBspeedcode7 = 30061.6
USBstoragecode8 = 30016.7 
USBspeedcode8 = 30061.7
USBstoragecode9 = 30016.8
USBspeedcode9 = 30061.8
USBstoragecode10 = 30016.9
USBspeedcode10 = 30061.9

# CD Legacy 1

diskspace1 = 100016.0.1
diskspeed1 = 100016.0.1
diskspace2 = 100016.1.1
diskspeed2 = 100016.1.1
diskspace3 = 100016.2.1
diskspeed3 = 100016.2.1
diskspace4 = 100016.3.1
diskspeed4 = 100016.3.1
diskspace5 = 100016.4.1
diskspeed5 = 100016.4.1
diskspace6 = 100016.5.1
diskspeed6 = 100016.5.1
diskspace7 = 100016.6.1
diskspeed7 = 100016.6.1
diskspace8 = 100016.7.1
diskspeed8 = 100016.7.1
diskspace9 = 100016.8.1
diskspeed9 = 100016.8.1
diskspace10 = 100016.9.1
diskspeed10 = 100016.9.1
diskspace11 = 100016.10.1
diskspeed11 = 100016.10.1
diskspace12 = 100016.11.1
diskspeed12 = 100016.11.1
diskspace13 = 100016.12.1
diskspeed13 = 100016.12.1
diskspace14 = 100016.13.1
diskspeed14 = 100016.13.1
diskspace15 = 100016.14.1
diskspeed15 = 100016.14.1
diskspace16 = 100016.15.1
diskspeed16 = 100016.15.1

# CD Legacy 2

diskspace1 = 100016.0.2
diskspeed1 = 100016.0.2
diskspace2 = 100016.1.2
diskspeed2 = 100016.1.2
diskspace3 = 100016.2.2
diskspeed3 = 100016.2.2
diskspace4 = 100016.3.2
diskspeed4 = 100016.3.2
diskspace5 = 100016.4.2
diskspeed5 = 100016.4.2
diskspace6 = 100016.5.2
diskspeed6 = 100016.5.2
diskspace7 = 100016.6.2
diskspeed7 = 100016.6.2
diskspace8 = 100016.7.2
diskspeed8 = 100016.7.2
diskspace9 = 100016.8.2
diskspeed9 = 100016.8.2
diskspace10 = 100016.9.2
diskspeed10 = 100016.9.2
diskspace11 = 100016.10.2
diskspeed11 = 100016.10.2
diskspace12 = 100016.11.2
diskspeed12 = 100016.11.2
diskspace13 = 100016.12.2
diskspeed13 = 100016.12.2
diskspace14 = 100016.13.2
diskspeed14 = 100016.13.2
diskspace15 = 100016.14.2
diskspeed15 = 100016.14.2
diskspace16 = 100016.15.2
diskspeed16 = 100016.15.2

# DVD Legacy 1

diskspace1 = 100016.0.3
diskspeed1 = 100016.0.3
diskspace2 = 100016.1.3
diskspeed2 = 100016.1.3
diskspace3 = 100016.2.3
diskspeed3 = 100016.2.3
diskspace4 = 100016.3.3
diskspeed4 = 100016.3.3
diskspace5 = 100016.4.3
diskspeed5 = 100016.4.3
diskspace6 = 100016.5.3
diskspeed6 = 100016.5.3
diskspace7 = 100016.6.3
diskspeed7 = 100016.6.3
diskspace8 = 100016.7.3
diskspeed8 = 100016.7.3
diskspace9 = 100016.8.3
diskspeed9 = 100016.8.3
diskspace10 = 100016.9.3
diskspeed10 = 100016.9.3
diskspace11 = 100016.10.3
diskspeed11 = 100016.10.3
diskspace12 = 100016.11.3
diskspeed12 = 100016.11.3
diskspace13 = 100016.12.3
diskspeed13 = 100016.12.3
diskspace14 = 100016.13.3
diskspeed14 = 100016.13.3
diskspace15 = 100016.14.3
diskspeed15 = 100016.14.3
diskspace16 = 100016.15.3
diskspeed16 = 100016.15.3

# DVD Legacy 2

diskspace1 = 100016.0.4
diskspeed1 = 100016.0.4
diskspace2 = 100016.1.4
diskspeed2 = 100016.1.4
diskspace3 = 100016.2.4
diskspeed3 = 100016.2.4
diskspace4 = 100016.3.4
diskspeed4 = 100016.3.4
diskspace5 = 100016.4.4
diskspeed5 = 100016.4.4
diskspace6 = 100016.5.4
diskspeed6 = 100016.5.4
diskspace7 = 100016.6.4
diskspeed7 = 100016.6.4
diskspace8 = 100016.7.4
diskspeed8 = 100016.7.4
diskspace9 = 100016.8.4
diskspeed9 = 100016.8.4
diskspace10 = 100016.9.4
diskspeed10 = 100016.9.4
diskspace11 = 100016.10.4
diskspeed11 = 100016.10.4
diskspace12 = 100016.11.4
diskspeed12 = 100016.11.4
diskspace13 = 100016.12.4
diskspeed13 = 100016.12.4
diskspace14 = 100016.13.4
diskspeed14 = 100016.13.4
diskspace15 = 100016.14.4
diskspeed15 = 100016.14.4
diskspace16 = 100016.15.4
diskspeed16 = 100016.15.4

# BLU-RAY Legacy 1

diskspace1 = 100016.0.5
diskspeed1 = 100016.0.5
diskspace2 = 100016.1.5
diskspeed2 = 100016.1.5
diskspace3 = 100016.2.5
diskspeed3 = 100016.2.5
diskspace4 = 100016.3.5
diskspeed4 = 100016.3.5
diskspace5 = 100016.4.5
diskspeed5 = 100016.4.5
diskspace6 = 100016.5.5
diskspeed6 = 100016.5.5
diskspace7 = 100016.6.5
diskspeed7 = 100016.6.5
diskspace8 = 100016.7.5
diskspeed8 = 100016.7.5
diskspace9 = 100016.8.5
diskspeed9 = 100016.8.5
diskspace10 = 100016.9.5
diskspeed10 = 100016.9.5
diskspace11 = 100016.10.5
diskspeed11 = 100016.10.5
diskspace12 = 100016.11.5
diskspeed12 = 100016.11.5
diskspace13 = 100016.12.5
diskspeed13 = 100016.12.5
diskspace14 = 100016.13.5
diskspeed14 = 100016.13.5
diskspace15 = 100016.14.5
diskspeed15 = 100016.14.5
diskspace16 = 100016.15.5
diskspeed16 = 100016.15.5

# BLU-RAY Legacy 2

diskspace1 = 100016.0.6
diskspeed1 = 100016.0.6
diskspace2 = 100016.1.6
diskspeed2 = 100016.1.6
diskspace3 = 100016.2.6
diskspeed3 = 100016.2.6
diskspace4 = 100016.3.6
diskspeed4 = 100016.3.6
diskspace5 = 100016.4.6
diskspeed5 = 100016.4.6
diskspace6 = 100016.5.6
diskspeed6 = 100016.5.6
diskspace7 = 100016.6.6
diskspeed7 = 100016.6.6
diskspace8 = 100016.7.6
diskspeed8 = 100016.7.6
diskspace9 = 100016.8.6
diskspeed9 = 100016.8.6
diskspace10 = 100016.9.6
diskspeed10 = 100016.9.6
diskspace11 = 100016.10.6
diskspeed11 = 100016.10.6
diskspace12 = 100016.11.6
diskspeed12 = 100016.11.6
diskspace13 = 100016.12.6
diskspeed13 = 100016.12.6
diskspace14 = 100016.13.6
diskspeed14 = 100016.13.6
diskspace15 = 100016.14.6
diskspeed15 = 100016.14.6
diskspace16 = 100016.15.6
diskspeed16 = 100016.15.6

# BLU-RAY Legacy 3

diskspace1 = 100016.0.7
diskspeed1 = 100016.0.7
diskspace2 = 100016.1.7
diskspeed2 = 100016.1.7
diskspace3 = 100016.2.7
diskspeed3 = 100016.2.7
diskspace4 = 100016.3.7
diskspeed4 = 100016.3.7
diskspace5 = 100016.4.7
diskspeed5 = 100016.4.7
diskspace6 = 100016.5.7
diskspeed6 = 100016.5.7
diskspace7 = 100016.6.7
diskspeed7 = 100016.6.7
diskspace8 = 100016.7.7
diskspeed8 = 100016.7.7
diskspace9 = 100016.8.7
diskspeed9 = 100016.8.7
diskspace10 = 100016.9.7
diskspeed10 = 100016.9.7
diskspace11 = 100016.10.7
diskspeed11 = 100016.10.7
diskspace12 = 100016.11.7
diskspeed12 = 100016.11.7
diskspace13 = 100016.12.7
diskspeed13 = 100016.12.7
diskspace14 = 100016.13.7
diskspeed14 = 100016.13.7
diskspace15 = 100016.14.7
diskspeed15 = 100016.14.7
diskspace16 = 100016.15.7
diskspeed16 = 100016.15.7

# BLU-RAY Legacy 4

diskspace1 = 100016.0.8
diskspeed1 = 100016.0.8
diskspace2 = 100016.1.8
diskspeed2 = 100016.1.8
diskspace3 = 100016.2.8
diskspeed3 = 100016.2.8
diskspace4 = 100016.3.8
diskspeed4 = 100016.3.8
diskspace5 = 100016.4.8
diskspeed5 = 100016.4.8
diskspace6 = 100016.5.8
diskspeed6 = 100016.5.8
diskspace7 = 100016.6.8
diskspeed7 = 100016.6.8
diskspace8 = 100016.7.8
diskspeed8 = 100016.7.8
diskspace9 = 100016.8.8
diskspeed9 = 100016.8.8
diskspace10 = 100016.9.8
diskspeed10 = 100016.9.8
diskspace11 = 100016.10.8
diskspeed11 = 100016.10.8
diskspace12 = 100016.11.8
diskspeed12 = 100016.11.8
diskspace13 = 100016.12.8
diskspeed13 = 100016.12.8
diskspace14 = 100016.13.8
diskspeed14 = 100016.13.8
diskspace15 = 100016.14.8
diskspeed15 = 100016.14.8
diskspace16 = 100016.15.8
diskspeed16 = 100016.15.8

# BLU-RAY Legacy 5

diskspace1 = 100016.0.9
diskspeed1 = 100016.0.9
diskspace2 = 100016.1.9
diskspeed2 = 100016.1.9
diskspace3 = 100016.2.9
diskspeed3 = 100016.2.9
diskspace4 = 100016.3.9
diskspeed4 = 100016.3.9
diskspace5 = 100016.4.9
diskspeed5 = 100016.4.9
diskspace6 = 100016.5.9
diskspeed6 = 100016.5.9
diskspace7 = 100016.6.9
diskspeed7 = 100016.6.9
diskspace8 = 100016.7.9
diskspeed8 = 100016.7.9
diskspace9 = 100016.8.9
diskspeed9 = 100016.8.9
diskspace10 = 100016.9.9
diskspeed10 = 100016.9.9
diskspace11 = 100016.10.9
diskspeed11 = 100016.10.9
diskspace12 = 100016.11.9
diskspeed12 = 100016.11.9
diskspace13 = 100016.12.9
diskspeed13 = 100016.12.9
diskspace14 = 100016.13.9
diskspeed14 = 100016.13.9
diskspace15 = 100016.14.9
diskspeed15 = 100016.14.9
diskspace16 = 100016.15.9
diskspeed16 = 100016.15.9

# SD Card Legacy 1

# SD Card Legacy 2

# SD Card Legacy 3

# HDD Legacy 1

# HDD Legacy 2

# HDD Legacy 3

# HDD Legacy 4

'''
'''
extra notes

USBstoragecode is the ID that identifies the storage capacity of the USB device
Storage guide (for legacy 1)
code1 = 8 MB 
code2 = 16 MB
code3 = 32 MB
code4 = 64 MB 
code5 = 128 MB
code6 = 256 MB
code7 = 512 MB
code8 = 600 MB 
code9 = 750 MB
code10 = 900 MB
Storage guide (for legacy 2)
code1 = 1 GB 
code2 = 2 GB
code3 = 4 GB
code4 = 8 GB
code5 = 16 GB
code6 = 32 GB
code7 = 48 GB
code8 = 64 GB 
code9 = 128 GB
code10 = 256 GB
Storage guide (for legacy 3)
code1 = 512 GB
code2 = 600 GB
code3 = 650 GB
code4 = 700 GB
code5 = 750 GB
code6 = 800 GB
code7 = 850 GB
code8 = 950 GB 
code9 = 1000 GB
code10 = 1 TB
USBspeedcode is the ID that identifies the speed of the USB device
Speed guide (for legacy 1)
code1 = 64 KB/S 
code2 = 128 KB/S 
code3 = 200 KB/S
code4 = 256 KB/S
code5 = 350 KB/S
code6 = 480 KB/S 
code7 = 720 KB/S 
code8 = 850 KB/S 
code9 = 1 MB/S 
code10 = 1.2 MB/S
Speed guide (for legacy 2)
code1 = 1.4 MB/S 
code2 = 1.8 MB/S 
code3 = 2.6 MB/S
code4 = 4 MB/S
code5 = 6 MB/S
code6 = 8 MB/S 
code7 = 12 MB/S 
code8 = 16 MB/S 
code9 = 24 MB/S 
code10 = 32 MB/S
Speed guide (for legacy 3)
code1 = 36 MB/S 
code2 = 48 MB/S 
code3 = 64 MB/S
code4 = 92 MB/S
code5 = 100 MB/S
code6 = 124 MB/S 
code7 = 128 MB/S 
code8 = 256 MB/S 
code9 = 360 MB/S 
code10 = 512 MB/S

'''
'''
more info

this part of the setup is normally done before sending out the hard drive, however the images are also offered for virtual machine uses
this makes it possible for us to include devices like floppy drives, cassettes, CDs, and DVDs in a relevant way. 
This feature makes using virtual machines easier, as you can have an old device that you couldn't plug into your computer run within the
virtual machine, and act as an external hard drive. This way for technical support, you can broadcast files to a specific person, and help
them set up their system, even from the other side of the planet
Floppy drives and cassettes are a lot more difficult compared to the other drives, as it normally takes more than 1 floppy to get 1 program
running
Since these hard drives have an operating system connected to them, it will be like installing an old system, but onto itself. Since you cannot
install a floppy image inside a floppy image (it just wouldn't be rational) you will have to use another drive such as a CD, DVD, USB, SD, SDD, or
HDD to hold the floppy images together. They will act as separate floppys within the big disk image, and are treated as separate drives. 
You can connect up to 500 Cassettes at once, and up to 2500 floppy images at once, however the chances of this being required are low, but it is
always an option!
CD and DVD images are pretty helpful! Since most older operating systems like Windows 95, Windows 98, Windows 2000, Windows XP, Vista, 7, 8, Mac OS
and others come on solid disks, their image can be quite helppul!

Device IDs are a risky area! We are safeguarding these well, as if these are modified, it can cause issues with your hard drive. They have strong
encryption (for CD, DVD, SD, HDD, USB, and SDD images, not floppy and cassettes) so it is a lot harder for people to get in. If you wish, you can
get updates for the security of them, they are always available
You can also modify them on your own, however you should ONLY try that on a secure virtual machine. You can modify numbers to change how much storage
the medium has, the read speed, the write speed, and the transfer speed. You should look through the guide in the source code to learn all the codes to
figure out how! There are a lot of them, and it may look pretty difficult, but they ALL follow a basic pattern
for user protection, once the device is set up, you cannot modify the numbers above what they are set to, but you can lower them (speed only, you can't 
modify the storage space. 

Floppy images and cassettes are designed for:

Windows 1.0
Windows 1.01
Windows 1.02
Windows 1.03
Windows 1.04
Windows 2.0
Windows 2.01
Windows 2.02
Windows 2.03
Windows 2.04
Windows 2.10
Windows 3.0
Windows 3.1
Windows 3.11
Windows 3.5
Windows 3.51
Windows NT 4
Windows 95
Windows 98
Windows 2000
Windows ME
Windows 98 Second Edition
Windows XP
Windows Server 2003
Mac System 1
Mac System 2
Mac System 3
Mac System 4
Mac System 5
Mac System 6
Mac System 7
Mac System 8
Mac System 9
Mac OS X 10.0
Mac OS X 10.1
Mac OS X 10.2
Mac OS X 10.3
Mac OS X 10.4
Mac OS X 10.5
Mac OS X 10.6
Mac OS X 10.7
Mac OS X 10.8
Mac OS X 10.9
Mac OS X 10.10
86 DOS 0.10
PC DOS 1.0
PC DOS 1.1
PC DOS 2.0
PC DOS 2.1
PC DOS 3.0
PC DOS 3.1
PC DOS 3.2
PC DOS 3.3
MS-DOS 3.31
DR-DOS 3.31
IBM DOS 4.0
DR-DOS 5.0
PC-DOS 5.0
MS-DOS 6.0
PC-DOS 6.1
MS-DOS 6.2
MS DOS 6.21
PC DOS 6.3
MS-DOS 6.22
PC DOS 7.0
OS/2 1.0	
OS/2 1.1
OS/2 1.2
OS/2 1.3
OS/2 2.0 
OS/2 2.0
OS/2 2.00.1
OS/2 for Windows
OS/2 2.11
OS/2 2.11 SMP
OS/2 Warp
OS/2 Warp Connect
OS/2 Warp, PowerPC Edition
OS/2 Warp Server 4
OS/2 Warp 4
OS/2 Warp Server Advanced SMP
WorkSpace On-Demand 1.0
WorkSpace On-Demand 2.0
OS/2 Warp Server for e-Business (version 4.50)
OS/2 Convenience Pack 1 (version 4.51)
OS/2 Convenience Pack 2 (version 4.52)
'''

'''

testconfirm = int(input("Did the setup look right? type 1 to confirm, type anything else and/or press enter to quit "))
if testconfirm == 9:
	print ("System setup successful!")
	print ("Shutting down, please wait")
else:
	print ("Shutting down")
'''
# Script for:

# This is really useful actually, I can keep all the older broken scripts as code examples :)
# This is the all-in-one boot image for version 5 (1.0.04A)
# I don't have it fully functional yet, I am just loading some key commands in
# I am only putting in the fully finished commands in, including some that require slight modification to finished
# This means important commands like 'help' 'compblog' and others are not implemented yet, as they are worked on more and more each update
# The commands I put in are pretty much in their final state 
# The integer commands are a great example of this concept
# They do what they are supposed to do, just to count
# However, the screensaver commands are different
# They still work like they are supposed to, but there is no stopping function yet
# Once I figure out that, I will be sure to implement it here
# A different more complex example is the compatibility commands 
# I don't have the drivers programmed for Legacy systems, and I don't plan to any-time soon, but I have the basic demo functions of the command implemented
# A lot of the notes here can be helpful, as they act as both information and dividers 
# This is all I havr to say, the definition list is right below - Sean Myrick 8/10/2018 01:01 pm 

# definition list:
'''
step2start
input 
SFBITINTCONF
8BITTEST1X
FC:\\
64BITTEST1X
32BITTEST1X
16BITTEST1X
64BITTEST1000X
INTCOMP
7NATIONARMYBINSCREENSAVER
SCREENSAVCON
PINEFALLSCREENSAVER
DNAFALLSCREENSAVER
testconfirm
'''
# blank space, too much orange for me (notepad++) - Sean Myrick 8/10/2018 12:55 pm
'''
print ("MEDOS 1.0.04")
print ("Debug Developer build 5")
print ("SYS = HDD")
print ("=======")
step2start = int(input("Type in 1 to continue booting"))
if (step2start == 1):
	print ("RUNNING DIRINT.INI")
step2start = int(input("test2"))
if (step2start == 1):
	print ("Complete!")
testconfirm = int(input("Did the setup look right? type 1 to confirm, type anything else and/or press enter to quit "))
if testconfirm == 1:
    print ("System setup successful!")
    print ("Shutting down, please wait")
else:
    print ("Shutting down")\
'''
#count = int
print ("MEDOS 1.0.04")
print ("Debug Developer build 5")
print ("SYS = HDD")
print ("=======")
step2start = int(input("Type in 1 to continue booting "))
if (step2start == 1):
	lcount = int
	lcount = 0
	lcount =+ 1
	print (lcount)
while not (lcount > 2):
	lcount + 1
	print ("Lines of code read:")
	print (lcount)
	print ("Welcome to MEDOS! Type 'help' to get help with commands")
YY = int
YY == 1
print (YY)
count = int
masinput = str
while YY == 1:
	masinput = str(input("FC:\\"))
# 8 bit integer counting command script (1 by one)
if input == ("FC:\\8BITTEST1X"):
	count = 0
	count = int
	count =+ 1
	print (count)
while not (count == 256):
    count =+ 1
    print (count)
else:
        print ("You have successfully counted to a 8 bit integer")
# 16 bit integer counting command script (1 by one)
if input == ("FC:\\16BITTEST1X"):
	count = 0
	count = int
	count =+ 1
	print (count)
while not (count == 65536):
    count =+ 1
    print (count)
else:
        print ("You have successfully counted to a 16 bit integer")
# 32 bit integer counting command script (1 by one)
if input == ("FC:\\32BITTEST1X"):
	count = 0
	count = int
	count =+ 1
	print (count)
while not (count == 2147483647):
    count =+ 1
    print (count)
else:
        print ("You have successfully counted to a 32 bit integer")
# 64 bit integer counting command script (1 by one)
if input == ("FC:\\64BITTEST1X"):
	count = 0
	count = int
	count =+ 1
	print (count)
while not (count == 9223372036854775807):
    count =+ 1
    print (count)
else:
        print ("You have successfully counted to a 64 bit integer")
# 64 bit integer counting command script BRICK MODE (1000 by 1000) - This WILL brick the OS 
if input == ("FC:\\64BITTEST1000X"):
	print ("WARNING! This command is unstable! You cannot count by 1000's and get to 9223372036854775807")
	print ("Once you hit within 999 numbers of that integer, it will either overflow, go into 128 bit or higher, or crash")
	print ("This was a joke feature, and might be removed or modified in the future")
	print ("Understand the risks")
SFBITINTCONF = str(input("Do you wish to continue? Y/N"))
if (SFBITINTCONF == Y):
	print ("Command started, no going back now")
	count = 0
	count = int
	count =+ 1000
	print (count)
while not (count == 9223372036854775807):
    count =+ 1000
    print (count)
else:
        print ("You have successfully counted to a 64 bit integer")
print ("End session")
# Integer compatibility log 2018
if input == ("FC:\\INTCOMP"):
	print ("_____________________________________________")
	print ("|Compatibility log for MEDOS Integer testing|")
	print ("\===========================================/")
	print ("                                             ")
	print ("_______________________________________________________________________________________________________")
	print ("                  |                |                           |                                      |")
	print ("8 bit test        ()  16 bit test  () 32 bit test              () 64 bit test                         |")
	print ("                  |                |                           |                                      |")
	print ("Windows 1.0       | Windows 3.0    | Windows NT 3.1            | Windows XP 64 bit                    |")
	print ("Windows 1.01      | Windows 3.1    | Windows NT 3.5            | Windows Vista                        |")
	print ("Windows 1.02      | Windows 3.2    | Windows 95                | Windows Server 2008                  |")
	print ("Windows 1.03      |                | Windows NT 4              | Windows 7                            |")
	print ("Windows 1.04      | Mac System 4   | Windows 98                | Windows Server 2008 R2               |")
	print ("Windows 2.0       | Mac System 5   | Windows 98 Second Edition | Windows 8                            |")
	print ("Windows 2.01      | Mac System 6   | Windows ME                | Windows Server 2012                  |")                
	print ("Windows 2.02      |                | Windows 2000              | Windows 8.1                          |")
	print ("Windows 2.03      | PC-DOS 7.0     | Windows XP Starter        | Windows Server 2012 R2               |")
	print ("Windows 2.04      |                | Windows XP Home           | Windows 10                           |")
	print ("Windows 2.10      |                | Windows XP Professional   | Windows Server 2016                  |")
	print ("                  |                | Windows Server 2003       |                                      |")
	print ("Mac System 1      |                | Windows Vista             | Mac OS X 10.3                        |")
	print ("Mac System 2      |                | Windows Server 2003 R2    | Mac OS X 10.4                        |")
	print ("Mac System 3      |                | Windows Server 2008       | Mac OS X 10.5                        |")
	print ("                  |                | Windows 7                 | Mac OS X 10.6                        |")
	print ("PC-DOS 1.0        |                | Windows Server 2008 R2    | Mac OS X 10.7                        |")
	print ("PC-DOS 2.0        |                | Windows 8                 | OS X 10.8                            |")
	print ("PC-DOS 3.0        |                | Windows Server 2012       | OS X 10.9                            |")
	print ("PC-DOS 4.0        |                | Windows 8.1               | OS X 10.10                           |")
	print ("PC-DOS 5.0        |                | Windows Server 2012 R2    | OS X 10.11                           |")
	print ("PC-DOS 6.0        |                | Windows 10                | MacOS 10.12                          |")
	print ("PC-DOS 6.1        |                | Windows Server 2016       | MacOS 10.13                          |")
	print ("                  |                |                           | MacOS 10.14                          |")
	print ("                  |                | Mac System 7              |                                      |")
	print ("                  |                | Mac System 7.6            | Android 5.0                          |")
	print ("                  |                | Mac System 8              | Android 5.1                          |")
	print ("                  |                | Mac System 9              | Android 6.0                          |")
	print ("                  |                | Mac OS X                  | Android 6.1                          |")
	print ("                  |                | Mac OS X 10.1             | Android 7.0                          |")
	print ("                  |                | Mac OS X 10.2             | Android 7.1                          |")
	print ("                  |                | Mac OS X 10.3             | Android 8.0                          |")
	print ("                  |                | Mac OS X 10.4             | Android 8.1                          |")
	print ("                  |                | Mac OS X 10.5             | Android 9.0                          |")
	print ("                  |                | Mac OS X 10.6             |                                      |")
	print ("                  |                |                           | iOS 7                                |")
	print ("                  |                | Android 1.0               | iOS 8                                |")
	print ("                  |                | Android 1.1               | iOS 9                                |")
	print ("                  |                | Android 1.5               | iOS 10                               |")
	print ("                  |                | Android 1.6               | iOS 10.3                             |")
	print ("                  |                | Android 2.0               | iOS 11                               |")
	print ("                  |                | Android 2.1               | iOS 12                               |")
	print ("                  |                | Android 2.2               |                                      |")
	print ("                  |                | Android 2.3               | Ubuntu 12.04                         |")
	print ("                  |                | Android 3.0               | Ubuntu 12.10                         |")
	print ("                  |                | Android 3.1               | Ubuntu 13.04                         |")
	print ("                  |                | Android 4.0               | Ubuntu 13.10                         |")
	print ("                  |                | Android 4.1               | Ubuntu 14.04                         |")
	print ("                  |                | Android 4.4               | Ubuntu 14.10                         |")
	print ("                  |                | Android 5.0               | Ubuntu 15.04                         |")
	print ("                  |                | Android 5.1               | Ubuntu 15.10                         |")
	print ("                  |                | Android 6.0               | Ubuntu 16.04                         |")
	print ("                  |                | Android 6.1               | Ubuntu 16.10                         |")
	print ("                  |                | Android 7.0               | Ubuntu 17.04                         |")
	print ("                  |                | Android 7.1               | Ubuntu 17.10                         |")
	print ("                  |                | Android 8.0               | Ubuntu 18.04                         |")
	print ("                  |                | Android 8.1               | Ubuntu 18.10                         |")
	print ("                  |                |                           |                                      |")
	print ("                  |                | iPhone OS 1               | Solaris 7                            |")
	print ("                  |                | iPhone OS 2               | Solaris 8                            |")
	print ("                  |                | iPhone OS 3               | Solaris 9                            |")
	print ("                  |                |                           | Solaris 10                           |")
	print ("                  |                | iOS 4                     | Solaris 11                           |")
	print ("                  |                | iOS 5                     |                                      |")
	print ("                  |                | iOS 6                     |                                      |")
	print ("                  |                | iOS 7                     |                                      |")
	print ("                  |                | iOS 8                     |                                      |")
	print ("                  |                | iOS 9                     |                                      |")
	print ("                  |                | iOS 10                    |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                | Ubuntu 4.04               |                                      |")
	print ("                  |                | Ubuntu 4.10               |                                      |")
	print ("                  |                | Ubuntu 5.04               |                                      |") 
	print ("                  |                | Ubuntu 5.10               |                                      |")
	print ("                  |                | Ubuntu 6.04               |                                      |")
	print ("                  |                | Ubuntu 6.10               |                                      |")
	print ("                  |                | Ubuntu 7.04               |                                      |")
	print ("                  |                | Ubuntu 7.10               |                                      |")
	print ("                  |                | Ubuntu 8.04               |                                      |")
	print ("                  |                | Ubuntu 8.10               |                                      |")
	print ("                  |                | Ubuntu 9.04               |                                      |")
	print ("                  |                | Ubuntu 9.10               |                                      |")
	print ("                  |                | Ubuntu 10.4               |                                      |")
	print ("                  |                | Ubuntu 10.10              |                                      |")
	print ("                  |                | Ubuntu 11.04              |                                      |")
	print ("                  |                | Ubuntu 11.10              |                                      |")
	print ("                  |                | Ubuntu 12.04              |                                      |")
	print ("                  |                | Ubuntu 12.10              |                                      |")
	print ("                  |                | Ubuntu 13.04              |                                      |")
	print ("                  |                | Ubuntu 13.10              |                                      |")
	print ("                  |                | Ubuntu 14.04              |                                      |")
	print ("                  |                | Ubuntu 14.10              |                                      |")
	print ("                  |                | Ubuntu 15.04              |                                      |")
	print ("                  |                | Ubuntu 15.10              |                                      |")
	print ("                  |                | Ubuntu 16.04              |                                      |")
	print ("                  |                | Ubuntu 16.10              |                                      |")
	print ("                  |                | Ubuntu 17.04              |                                      |")
	print ("                  |                | Ubuntu 17.10              |                                      |")
	print ("                  |                | Ubuntu 18.04              |                                      |")
	print ("                  |                | Ubuntu 18.10              |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("                  |                |                           |                                      |")
	print ("=======================================================================================================")
	print ("Total entry slots: 8 bit = 256 | 16 bit = 256 | 32 bit = 256 | 64 bit = 256 | Total = 1024")
	print ("Used slots: unmeasured")
	print ("Available slots: unmeasured")
	print ("==========================================================================================================")
else:
	print ("Unknown command, please try a different command. Remember, commands are CaSe SenSiTiVe. If you need further assistance, type 'help' in the search but don't put the quotes")
# 7 Nation Army binary screensaver (I got this screensaver from a YouTube comment section on a floppatron video. Someone converted a song into binary, and I thought it would be funny to make it into a screensaver
if input == ("FC:\\7NATIONARMYBINSCREENSAVER"):
	print ("WARNING! Screensavers are unstable in this build")
	print ("The screensaver will run correctly, but the only way to stop it is to shut down the system through the close button")
	print ("You will have to restart your session, but you can enjoy the screensaver")
	print ("Understand the risks")
SCREENSAVCON = str(input("Do you want to continue? Y/N"))
if SCREENSAVCON == (Y):
	print ("The screensaver has started, there is no going back now")
	x = 1
	while x == 1:
		print ("01001001001001110110110100100000011001110110111101101110011011100110000100100000011001100110100101100111011010000111010000100000001001110110010101101101001000000110000101101100011011000000110100001010010000010010000001110011011001010111011001100101011011100010000001101110011000010111010001101001011011110110111000100000011000010111001001101101011110010010000001100011011011110111010101101100011001000110111000100111011101000010000001101000011011110110110001100100001000000110110101100101001000000110001001100001011000110110101100001101000010100101010001101000011001010111100100100111011100100110010100100000011001110110111101101110011011100110000100100000011100100110100101110000001000000110100101110100001000000110111101100110011001100000110100001010010101000110000101101011011010010110111001100111001000000111010001101000011001010110100101110010001000000111010001101001011011010110010100100000011100100110100101100111011010000111010000100000011000100110010101101000011010010110111001100100001000000110110101111001001000000110001001100001011000110110101100001101000010100000110100001010010000010110111001100100001000000100100100100111011011010010000001110100011000010110110001101011011010010110111001100111001000000111010001101111001000000110110101111001011100110110010101101100011001100010000001100001011101000010000001101110011010010110011101101000011101000000110100001010010000100110010101100011011000010111010101110011011001010010000001001001001000000110001101100001011011100010011101110100001000000110011001101111011100100110011101100101011101000000110100001010010000100110000101100011011010110010000001100001011011100110010000100000011001100110111101110010011101000110100000100000011101000110100001110010011011110111010101100111011010000010000001101101011110010010000001101101011010010110111001100100000011010000101001000010011001010110100001101001011011100110010000100000011000010010000001100011011010010110011101100001011100100110010101110100011101000110010100001101000010100100000101101110011001000010000001110100011010000110010100100000011011010110010101110011011100110110000101100111011001010010000001100011011011110110110101101001011011100110011100100000011001100111001001101111011011010010000001101101011110010010000001100101011110010110010101110011000011010000101001010011011000010111100101110011001000000110110001100101011000010111011001100101001000000110100101110100001000000110000101101100011011110110111001100101000011010000101000001101000010100100010001101111011011100010011101110100001000000111011101100001011011100111010000100000011101000110111100100000011010000110010101100001011100100010000001100001011000100110111101110101011101000010000001101001011101000000110100001010010001010111011001100101011100100111100100100000011100110110100101101110011001110110110001100101001000000110111101101110011001010010011101110011001000000110011101101111011101000010000001100001001000000111001101110100011011110111001001111001001000000111010001101111001000000111010001100101011011000110110000001101000010100100010101110110011001010111001001111001011011110110111001100101001000000110101101101110011011110111011101110011001000000110000101100010011011110111010101110100001000000110100101110100000011010000101001000110011100100110111101101101001000000111010001101000011001010010000001010001011101010110010101100101011011100010000001101111011001100010000001000101011011100110011101101100011000010110111001100100001000000111010001101111001000000111010001101000011001010010000001101000011011110111010101101110011001000111001100100000011011110110011000100000011010000110010101101100011011000000110100001010000011010000101001000001011011100110010000100000011010010110011000100000010010010010000001100011011000010111010001100011011010000010000001101001011101000010000001100011011011110110110101101001011011100110011100100000011000100110000101100011011010110010000001101101011110010010000001110111011000010111100100001101000010100100100100100111011011010010000001100111011011110110111001101110011000010010000001110011011001010111001001110110011001010010000001101001011101000010000001110100011011110010000001111001011011110111010100001101000010100100000101101110011001000010000001110100011010000110000101110100001000000110000101101001011011100010011101110100001000000111011101101000011000010111010000100000011110010110111101110101001000000111011101100001011011100111010000100000011101000110111100100000011010000110010101100001011100100000110100001010010000100111010101110100001000000111010001101000011000010111010000100111011100110010000001110111011010000110000101110100001000000100100100100111011011000110110000100000011001000110111100001101000010100100000101101110011001000010000001110100011010000110010100100000011001100110010101100101011011000110100101101110011001110010000001100011011011110110110101101001011011100110011100100000011001100111001001101111011011010010000001101101011110010010000001100010011011110110111001100101011100110000110100001010010100110110000101111001011100110010000001100110011010010110111001100100001000000110000100100000011010000110111101101101011001010000110100001010000011010000101001001001001001110110110100100000011001110110111101101001011011100110011100100000011101000110111100100000010101110110100101100011011010000110100101110100011000010000110100001010010001100110000101110010001000000110011001110010011011110110110100100000011101000110100001101001011100110010000001101111011100000110010101110010011000010010000001100110011011110111001000100000011001010111011001100101011100100110110101101111011100100110010100001101000010100100100100100111011011010010000001100111011011110110111001101110011000010010000001110111011011110111001001101011001000000111010001101000011001010010000001110011011101000111001001100001011101110000110100001010010011010110000101101011011001010010000001110100011010000110010100100000011100110111011101100101011000010111010000100000011001000111001001101001011100000010000001101111011101010111010000100000011011110110011000100000011001010111011001100101011100100111100100100000011100000110111101110010011001010000110100001010010000010110111001100100001000000100100100100111011011010010000001100010011011000110010101100101011001000110100101101110011001110010110000100000011000010110111001100100001000000100100100100111011011010010000001100010011011000110010101100101011001000110100101101110011001110010110000100000011000010110111001100100001000000100100100100111011011010010000001100010011011000110010101100101011001000110100101101110011001110000110100001010010100100110100101100111011010000111010000100000011000100110010101100110011011110111001001100101001000000111010001101000011001010010000001101100011011110111001001100100000011010000101001000001011011000110110000100000011101000110100001100101001000000111011101101111011100100110010001110011001000000110000101110010011001010010000001100111011011110110111001101110011000010010000001100010011011000110010101100101011001000010000001100110011100100110111101101101001000000110110101100101000011010000101001000001011011100110010000100000010010010010000001110111011010010110110001101100001000000111001101101001011011100110011100100000011011100110111100100000011011010110111101110010011001010000110100001010010000010110111001100100001000000111010001101000011001010010000001110011011101000110000101101001011011100111001100100000011000110110111101101101011010010110111001100111001000000110011001110010011011110110110100100000011011010111100100100000011000100110110001101111011011110110010000001101000010100101010001100101011011000110110000100000011011010110010100100000011001110110111100100000011000100110000101100011011010110010000001101000011011110110110101100101")
# Pinefall screensaver, a cool ASCII screensaver of a really thin pine tree, i guess
if input == ("FC:\\PINEFALLSCREENSAVER"):
	print ("WARNING! Screensavers are unstable in this build")
	print ("The screensaver will run correctly, but the only way to stop it is to shut down the system through the close button")
	print ("You will have to restart your session, but you can enjoy the screensaver")
	print ("Understand the risks")
SCREENSAVCON = str(input("Do you want to continue? Y/N"))
if SCREENSAVCON == (Y):
	x = 1
	while x == 1:
		print ("=")
		print ("=")
		print ("=")
		print ("==")
		print ("==")
		print ("==")
		print ("===")
		print ("===")
		print ("===")
		print ("====")
		print ("====")
		print ("====")
		print ("=====")
		print ("=====")
		print ("=====")
		print ("======")
		print ("======")
		print ("======")
		print ("=======")
		print ("=======")
		print ("=======")
		print ("========")
		print ("========")
		print ("========")
		print ("=========")
		print ("=========")
		print ("=========")
		print ("==========")
		print ("==========")
		print ("==========")
		print ("===========")
		print ("===========")
		print ("===========")
		print ("============")
		print ("============")
		print ("============")
		print ("=============")
		print ("=============")
		print ("=============")
		print ("==============")
		print ("==============")
		print ("==============")
		print ("===============")
		print ("===============")
		print ("===============")
		print ("==============")
		print ("==============")
		print ("==============")
		print ("=============")
		print ("=============")
		print ("=============")
		print ("============")
		print ("============")
		print ("============")
		print ("===========")
		print ("===========")
		print ("===========")
		print ("==========")
		print ("==========")
		print ("==========")
		print ("=========")
		print ("=========")
		print ("=========")
		print ("========")
		print ("========")
		print ("========")
		print ("=======")
		print ("=======")
		print ("=======")
		print ("======")
		print ("======")
		print ("======")
		print ("=====")
		print ("=====")
		print ("=====")
		print ("====")
		print ("====")
		print ("====")
		print ("===")
		print ("===")
		print ("===")
		print ("==")
		print ("==")
		print ("==")
		x + 0
# DNA Farm screensaver - A DNA strip that loops endlessly, however I kind of want a more thick version, this will do for now
if input == ("FC:\\DNAFALLSCREENSAVER"):
	print ("WARNING! Screensavers are unstable in this build")
	print ("The screensaver will run correctly, but the only way to stop it is to shut down the system through the close button")
	print ("You will have to restart your session, but you can enjoy the screensaver")
	print ("Understand the risks")
SCREENSAVCON = str(input("Do you want to continue? Y/N"))
if SCREENSAVCON ==(Y):
	print ("Screensaver started, you can't go back now")
	x = 1
	while x == 1:
		print ("|-----------------|")
		print ("\---------------/  ")
		print (" ~-_---------_-~   ")
		print ("   ~-_---_-~       ")
		print ("      ~-_		   ")
		print ("    _-~---~-_      ")
		print ("  _-~---------~-_  ")
		print (" /---------------\ ")
		print ("|-----------------|")
		x + 0
# not including platformers sky yet, as the screensaver isn't made correctly
'''
doesn't loop
poor design
'''
# Windows 3x Compatibilty command, 3.RUN
if input == ("FC:\\3.RUN"):
	print ("Windows 3 compatibility center")
	print ("1 Windows 3.0")
	print ("2 Windows 3.1")
	print ("3 Windows 3.11")
	print ("4 Windows 3.2")
	print ("5 Windows 3.5")
	print ("6 Windows NT 3.5")
	print ("7 Windows NT 3.1")
	print ("8 Windows NT 3.11")
	print ("9 Windows NT 3.51")
	print ("Choose a number 0-9 then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")
# Windows 9x compatibility command, 9XRUN
if input == ("FC:\\9XRUN"):
	print ("Windows 9x compatibility center")
	print ("1 Windows NT 4")
	print ("2 Windows 95")
	print ("3 Windows Chicago")
	print ("4 Windows 98")
	print ("5 Windows Memphis")
	print ("6 Windows 98 Second Edition")
	print ("7 Windows Millennium")
	print ("8 Windows Millennium Edition")
	print ("Choose a number 1-8 then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")
# Android compatibilty command, ANDRORUN
if input == ("FC:\\ANDRORUN"):
	print ("Android compatibility center")
	print ("0 Android 1.1")
	print ("1 Android 1.5")
	print ("2 Android 1.6")
	print ("3 Android 2.0")
	print ("4 Android 2.1")
	print ("5 Android 2.2")
	print ("6 Android 2.3")
	print ("7 Android 3.0")
	print ("8 Android 4.0")
	print ("9 Android 4.1")
	print ("A Android 4.4")
	print ("B Android 5.0")
	print ("C Android 5.1")
	print ("D Android 6.0")
	print ("E Android 6.1")
	print ("F Android 7.0")
	print ("G Android 7.1")
	print ("H Android 8.0")
	print ("I Android 8.1")
	print ("J Android 9.0")
	print ("K Android 9.1")
	print ("L Android 10.0")
	print ("Choose a number 0-9 or A-L then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")
# Memory guide command, teaching people about storage from bytes to Yottabytes. Command = BGUIDE
if input == ("FC:\\BGUIDE"):
	print ("Welcome to the memory guide!")
	print ("Learn more about computer storage here")
	print ("-----")
	print ("Memory size")
	print ("Byte = 8 bits")
	print ("Kilobyte = 1024 bytes")
	print ("Megabyte = 1024 Kilobytes")
	print ("Gigabyte = 1024 Megabytes")
	print ("Terabyte = 1024 Gigabytes")
	print ("Petabyte = 1024 Terabytes (this system is incapable of holding petabytes of memory)")
	print ("Exabyte = 1024 Petabytes (this system is incapable of holding exabytes of memory)")
	print ("Zettabyte = 1024 Exabytes (this system is incapable of holding zettabytes of memory)")
	print ("Yottabyte = 1024 Zettabytes (this system is incapable of holding yottabytes of memory")
	print ("-----")
	print ("Internet Speed (upload and download)")
	print ("Kilobit connection = 125 bytes per second")
	print ("Megabit connection = 125 Kilobits per second")
	print ("Gigabit connection = 125 Megabits per second")
	print ("Terabit connection = 125 Gigabits per second (this system is incapable of reaching that speed)")
	print ("Petabit connection = 125 Terabits per second (this system is incapable of reaching that speed)")
	print ("Exabit connection = 125 Petabits per second (this systrem is incapable of reaching that speed)")
	print ("Zettabit connection = 125 Exabits per second (this system is incapable of reaching that speed)")
	print ("Yottabit connection = 125 Zettabits per second (this system is incapable of reaching that speed)")
	print ("-----")
	print ("Integers of memory size")
	print ("Byte = 1 Squared 8 bits")
	print ("Kilobyte = 2 Squared 10 bytes")
	print ("Megabyte = 2 Squared 20 bytes")
	print ("Gigabyte = 2 Squared 30 bytes")
	print ("Terabyte = 2 Squared 40 bytes")
	print ("Petabyte = 2 Squared 50 bytes")
	print ("Exabyte = 10 Squared 18 bytes")
	print ("Zettabyte = 10 Squared 21 bytes")
	print ("Yottabyte = 10 Squared 24 bytes")
	print ("-----")
	print ("Working with memory")
	print ("A computer works with memory in many ways such as:")
	print ("Read speed")
	print ("Write speed")
	print ("Download speed")
	print ("Upload speed")
	print ("Connection speed")
	print ("CPU speed")
	print ("Disk speed")
	print ("GPU speed")
	print ("Network speed")
	print ("Utilization speed")
	print ("Cache speed")
	print ("Clock speed")
	print ("Pool speed")
	print ("Response speed")
	print ("Send speed")
	print ("Receive speed")
	print ("Decode speed")
	print ("Execute speed")
	print ("Processor speed")
	print ("Processing speed")
	print ("Loading speed")
	print ("Packets")
	print ("Transfer")
	print ("Processes")
	print ("Threads")
	print ("Handles")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")
# iOS compatibility command. Command = IORUN
if input == ("FC:\\IORUN"):
	print ("iOS compatibility center")
	print ("0 iOS 1")
	print ("1 iOS 2")
	print ("2 iOS 3")
	print ("3 iOS 4")
	print ("4 iOS 5")
	print ("5 iOS 6")
	print ("6 iOS 7")
	print ("7 iOS 8")
	print ("8 iOS 9")
	print ("9 iOS 10")
	print ("A iOS 11")
	print ("B iOS 12")
	print ("Choose a number 0-9 or A-B then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")
# Keyboard testing command. Command = KBRDTEST
if input == ("FC:\\KBRDTEST"):
	print ("US Keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] | a |")
	print ("| A | b | B | c | C | d | D |")
	print ("| e | E | f | F | g | G | h |")
	print ("| H | i | I | j | J | k | K |")
	print ("| l | L | m | M | n | N | o |")
	print ("| O | p | P | q | Q | r | R |")
	print ("| s | S | t | T | u | U | v |")
	print ("| V | w | W | x | X | y | Y |")
	print ("| z |   |   |   |   |   | Z |")
	print ("Spanish keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |") 
	print ("French keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("German keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Russian keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Indonesian keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Swedish keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Chinese keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Japanese keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Korean keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("UK keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Zulu keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Greek keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Mandarin keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Roman keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Dutch keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Arabic keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Danish keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Italian keyboard")
	print ("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |")
	print ("| 7 | 8 | 9 | # | . | , | > |")
	print ("| < | ? | / | \ | | | : | ; |")
	print ("| [ | ' | - | _ | = | + | ~ |")
	print ("| ` | ! | @ | $ | % | ^ | & |")
	print ("| * | ( | ) | { | } | ] |   |")
	print ("|   |   |   |   |   |   |   |")
	print ("Unicode keyboard")
	print ("|   |   |   |   |   |   |   |")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")	
# Mac Classic Compatibility command. Command name = MASYSRUN
if input == ("FC:\\MASYSRUN"):
	print ("Mac System compatibility center")
	print ("0 System 1")
	print ("1 System 2")
	print ("2 System 3")
	print ("3 System 4")
	print ("4 System 5")
	print ("5 System 6")
	print ("6 System 7")
	print ("7 System 8")
	print ("8 System 8.1")
	print ("9 System 8.5")
	print ("A System 8.6")
	print ("B System 9")
	print ("C System 9.1")
	print ("D System 9.2.2")
	print ("Choose a number 0-9 or A-D then click enter to continue compatibility testing")
	print ("Type XE to quit")
else: 
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")	
# Mac OS X, OS X, and Modern MacOS Compatibility command = MCXRUN
if input == ("FC:\\MCXRUN"):
	print ("Mac OS X compatibility center")
	print ("0 Mac OS X 10.0")
	print ("1 Mac OS X 10.1")
	print ("2 Mac OS X 10.2")
	print ("3 Mac OS X 10.3")
	print ("4 Mac OS X 10.4")
	print ("5 Mac OS X 10.5")
	print ("6 Mac OS X 10.6")
	print ("7 Mac OS X 10.7")
	print ("8 OS X 10.8")
	print ("9 OS X 10.9")
	print ("A OS X 10.10")
	print ("B OS X 10.11")
	print ("C MacOS 10.12")
	print ("D MacOS 10.13")
	print ("E MacOS 10.14")
	print ("Choose a number 0-9 or A-E then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")		
# Ubuntu compatibilty command. Command = UBURUN
if input == ("FC:\\UBURUN"):
	print ("Ubuntu compatibility center")
	print ("U1 Ubuntu 4.10")
	print ("U2 Ubuntu 5.04")
	print ("U3 Ubuntu 5.10")
	print ("U4 Ubuntu 6.04")
	print ("U5 Ubuntu 6.10")
	print ("U6 Ubuntu 7.04")
	print ("U7 Ubuntu 7.10")
	print ("U8 Ubuntu 8.04")
	print ("U9 Ubuntu 8.10")
	print ("D1 Ubuntu 9.04")
	print ("D2 Ubuntu 9.10")
	print ("D3 Ubuntu 10.04")
	print ("D4 Ubuntu 10.10")
	print ("D5 Ubuntu 11.04")
	print ("D6 Ubuntu 11.10")
	print ("D7 Ubuntu 12.04")
	print ("D8 Ubuntu 12.10")
	print ("D9 Ubuntu 13.04")
	print ("UD Ubuntu 13.10")
	print ("DU Ubuntu 14.04")
	print ("UD1 Ubuntu 14.10")
	print ("UD2 Ubuntu 15.04")
	print ("UD3 Ubuntu 15.10")
	print ("UD4 Ubuntu 16.04")
	print ("UD5 Ubuntu 16.10")
	print ("UD6 Ubuntu 17.04")
	print ("UD7 Ubuntu 17.10")
	print ("UD8 Ubuntu 18.04")
	print ("UD9 Ubuntu 18.10")
	print ("Type one of the given codes to change Ubuntu compatibility settings")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")		
# Windows Vista, Windows Server 2008 & R2 + Windows 7 compatibility command - the Aero legacy - Command = V7RUN
if input == ("FC:\\V7RUN"):
	print ("Windows Vista/Windows 7 compatibility center")
	print ("A Windows Vista no service pack")
	print ("B Windows Vista service pack 1")
	print ("C Windows Vista Service pack 2")
	print ("D Windows 7 No service pack")
	print ("E Wndows 7 Service pack 1")
	print ("F Windows Server 2008")
	print ("G Windows Server 2008 R2")
	print ("H Windows Longhorn")
	print ("I Windows Blackcomb")
	print ("0 Home edition")
	print ("1 Home Premium")
	print ("2 Business edition")
	print ("3 Ultimate edition")
	print ("4 Starter edition")
	print ("5 Enterprise edition")
	print ("6 Professional edition")
	print ("Choose a letter A-I followed by a number 0-6 then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")			
# Windows XP and Server 2003 compatibility center - Command = XPRUN
if input == ("FC:\\XPRUN"):
	print ("Windows XP compatibility center")
	print ("A Windows XP no service pack")
	print ("B Windows XP service pack 1")
	print ("C Windows XP Service pack 2")
	print ("D Windows XP Service pack 3")
	print ("E Windows Server 2003")
	print ("F Windows Server 2003 R2")
	print ("G Windows Whistler")
	print ("0 Home edition")
	print ("1 Professional edition")
	print ("2 N edition")
	print ("3 X64 edition")
	print ("4 Starter edition")
	print ("5 Media center edition")
	print ("6 Embedded edition")
	print ("Choose a letter A-G followed by a number 0-6 then click enter to continue compatibility testing")
	print ("Type XE to quit")
else:
	print ("Unknown command, please try a different format. If you are still struggling, type in 'help' for guidance. Remember, commands are CaSe SeNsItIvE. Do not include the quotes in command help guides")				
testconfirm = int(input("Did the command look right? type 1 to confirm, type anything else and/or press enter to quit "))
if testconfirm == 1:
	print ("Command test successful!")
	print ("Shutting down, please wait")
else:
    print ("Shutting down")