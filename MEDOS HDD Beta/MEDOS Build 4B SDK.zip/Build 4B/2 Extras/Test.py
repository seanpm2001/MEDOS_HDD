'''
print ("MEDOS Beta build 2")
print ("Developer debug build")
print ("Checking Memory")
print ("Total disk space: 16 TB")
print ("Speed: 6 MB/S")
print ("32 bit processor")
print ("Current directory is FC:/")
print ("File count: 5")
print ("Memory used: 20000 bytes")
print ("Run a command to begin, type help for help")
in1 = input("FC:/")
if (in1 = ("dir")): 
	print ("Directory of FC1")
	print ("Test.txt")
	print ("Test.bmp")
	print ("Test.wav")
	print ("Test.py")
	print ("Test.rtf")
if (in1 = ("help")):
	print ("Help list")
	print ("DIR = Directory")
	print ("CLS = Clear screen")
	print ("HELP = Help guide")
	print ("RUN = Run a program/file")
	print ("DEL = Delete the selected file")
	print ("COLOR = Change the text color of the terminal")
	print ("EXIT = Shut down the system")
	print ("CD = Choose a directory, type .. or the directory name afterwards, and you will go to the next directory")
	print ("PLAY = Play the currently selected audio or video")
	print ("EJECT = Eject the system, make it ready for ejecting the drive")
	print ("NETW = Change the current network")
	print ("DISCON = Disconnect from the internet, go offline")
if (in1 = ("cls")):
	print ("This command is unavailable")
if (in1 = ("run")):
	print ("The syntax of the command is incorrect")
if (in1 = ("del")):
	print ("The syntax of the command is incorrect")
if (in1 = ("color")):
	print ("This command is unavailable")
if (in1 = ("exit")):
	print ("This command is unavailable")
if (in1 = ("CD")):
	print ("This command is unavailable")
if (in1 = ("play")):
	print ("This command is unavailable")
if (in1 = ("eject")):
	print ("The syntax of the command is incorrect")
if (in1 = ("netw")):
	print ("This command is unavailable")
if (in1 = ("discon")):
	print ("This command is unavailable")
else:
	print (in1)
'''
'''
print ("MEDOS Beta build 1")
print ("Developer debug build")
print ("Checking Memory")
print ("Total disk space: 16 TB")
print ("Speed: 6 MB/S")
print ("32 bit processor")
print ("Current directory is FC:/")
print ("File count: 5")
print ("Memory used: 20000 bytes")
print ("Run a command to begin, type help for help")
in1 = input("FC:/")
if (in1 == ("dir")): 
    print ("Directory of FC1")
    print ("Test.txt")
    print ("Test.bmp")
    print ("Test.wav")
    print ("Test.py")
    print ("Test.rtf")
	else:
		if (in1 == ("help")):
			print ("Help list")
			print ("DIR = Directory")
			print ("CLS = Clear screen")
			print ("HELP = Help guide")
			print ("RUN = Run a program/file")
			print ("DEL = Delete the selected file")
			print ("COLOR = Change the text color of the terminal")
			print ("EXIT = Shut down the system")
			print ("CD = Choose a directory, type .. or the directory name afterwards, and you will go to the next directory")
			print ("PLAY = Play the currently selected audio or video")
			print ("EJECT = Eject the system, make it ready for ejecting the drive")
			print ("NETW = Change the current network")
			print ("DISCON = Disconnect from the Internet, go offline")
			print ("DRCHECK = Test your drives memory")
			print ("SPCHK = Calculate the amount of space being used")
			print ("VMOUTRUN = Use this command to launch programs OUTSIDE of the hard drive operating system, and onto the targeted receiver device")
			print ("VMORUTOG = Toggle launching programs outside of the hard drive operating systems to the other device on and off")
			print ("COMPBLOG = View the file compatibility of the system")
			print ("PREVTOG = Toggle file previews")
			print ("UPDUSR2 = Check for updates for the network receiver device")
			print ("RENAME = Rename the selected file/directory")
			print ("URENAME = Undo the recent renaming action")
			print ("CALC = Run a calculator")
			print ("USR2 = change the settings for the receiver device")
			else:
				if (in1 == ("cls")):
					print ("This command is unavailable")
					else:
						if (in1 == ("run")):
							print ("The syntax of the command is incorrect")
							else:
								if (in1 == ("del")):
									print ("The syntax of the command is incorrect")
									else:
										if (in1 == ("color")):
											print ("This command is unavailable")
											else:
												if (in1 == ("exit")):
													print ("This command is unavailable")
													else:
														if (in1 == ("CD")):
															print ("This command is unavailable")
															else:
																if (in1 == ("play")):
																	print ("This command is unavailable")
																	else:
																		if (in1 == ("eject")):
																			print ("The syntax of the command is incorrect")
																			else:	
																				if (in1 == ("netw")):
																					print ("This command is unavailable")
																					else:
																						if (in1 == ("discon")):
																							print ("This command is unavailable"
																							else:
																								print (in1)
																								if (in1 == ("drcheck")
																									print ("Testing memory, please wait..."_
																									else:
																										if (in1 == SPCHK")
																											print ("Calculating all files on your drive please wait...")
																											print ("This will take a few moments")
																											else: 
																												if (in1 == VMOUTRUN")
																													print ("Select a program to run on |USER2|")
																													else:
																														if (in1 == "VMRUTOG")
																															if (ftoguser = 1):
																																print ("Turning off outtoggle for |USER2|")
																																ftoguser = 0
																																else:
																																	if (ftoguser = 0):
																																		print ("Turning on outtoggle for |USER2|")
																																		ftoguser = 1
																																		else:
																																			if (in1 == "COMPBLOG")
																																				print ("File compatibility for MEDOS HDD")
																																				print ("Documents")
																																				print ("RTF")
																																				print ("TXT")
																																				print ("XPS")
																																				print ("ODS")
																																				print ("ODT")
																																				print ("ODX")
																																				print ("PDF")
																																				print ("Images")
																																				print ("BMP")
																																				print ("DMP")
																																				print ("PNG")
																																				print ("JPEG")
																																				print ("JPE")
																																				print ("JFIF")
																																				print ("GIF")
																																				print ("TIF")
																																				print ("TIFF")
																																				print ("SVG")
																																				print ("PSD")
																																				print ("ICO")
																																				print ("ICN")
																																				print ("PNS")
																																				print ("Videos")
																																				print ("MP4")
																																				print ("MP2")
																																				print ("AVI")
																																				print ("WMV")
																																				print ("3GP")
																																				print ("WEBM")
																																				print ("WLMP")
																																				print ("WMMP")
																																				print ("MOV")
																																				print ("M4V")
																																				print ("MKV")
																																				print ("Music")
																																				print ("OGG")
																																				print ("MP3")
																																				print ("MID")
																																				print ("MIDI")
																																				print ("FLAC")
																																				print ("WAV")
																																				print ("System")
																																				print ("SYS")
																																				print ("PY")
																																				print ("BAT")
																																				print ("DAT")
																																				print ("INI")
																																				print ("SLN")
																																				print ("EXE")
																																				print ("0")
																																				print ("Media")
																																				print ("IMG")
																																				print ("IMAGE")
																																				print ("ISO")
																																				print ("ZIP")
																																				print ("7Z")
																																				print ("TAR")
																																				print ("RAR")
																																				print ("ISO")
																																				print ("DMG")
																																				print ("Other")
																																				print ("URL")
																																				print ("INK")
																																				print ("TORRENT")
																																				else:
																																					if (in1 == "PREVTOG")
																																						if (PRTOG == 1):
																																							print ("Turning off file previews")
																																							PRTOG == 0
																																							else:
																																								if (PRTOG == 0):
																																									print ("Turning on file preview")
																																									else:
																																										if (in1 == "UPDUSR2")
																																											print ("Checking for updates for |USER2|")
																																											else:
																																												if (in1 == "RENAME")
																																													print ("Rename a file")
																																													else:
																																														if (in1 == "URENAME")
																																															print ("Do you want to revert the last rename? Y/N")
																																															else:
																																																if (in1 == CALC")
																																																	print ("Starting calculator")
																																																	else:
																																																		if (in1 == "USR2")
																																																			print ("Change settings for the receiver device, press ESC to cancel, TAB to quit")
																																																			print ("Device location {}")
																																																			print ("Device size {}")
																				
																																																
																																							
																																						
'''																																																																																			